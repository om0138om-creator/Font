# ✍️ Font Creator Pro

**تطبيق Android احترافي لإنشاء الخطوط TTF من الهاتف**

> تصميم: **عمر سنجق** و **محمود سنجق** | [@BugFreeCode](https://t.me/BugFreeCode)

---

## 🚀 خطوات التشغيل الكاملة

### الخطوة 1 — إعداد Supabase

1. اذهب إلى [supabase.com](https://supabase.com) وأنشئ مشروعاً جديداً مجانياً
2. افتح **SQL Editor** والصق محتوى `supabase/migrations/001_initial.sql` واضغط **Run**
3. من **Authentication → Providers** فعّل **Google** وأضف Client ID و Secret من [Google Cloud Console](https://console.cloud.google.com)
4. أضف Redirect URL في Supabase: `fontcreatorpro://auth/callback`
5. من **Settings → API** احتفظ بـ:
   - `Project URL`
   - `anon/public key`

### الخطوة 2 — إعداد EAS (Expo Application Services)

1. أنشئ حساباً مجانياً على [expo.dev](https://expo.dev)
2. شغّل: `eas init` لربط المشروع (احتفظ بـ `projectId`)
3. ضع الـ `projectId` في `app.json` في:
   ```json
   "extra": { "eas": { "projectId": "YOUR_ID" } }
   ```

### الخطوة 3 — إعداد متغيرات البيئة

انسخ `.env.example` إلى `.env`:
```
EXPO_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJ...
EXPO_PUBLIC_ADMIN_EMAIL=om011013om@gmail.com
```

### الخطوة 4 — رفع على GitHub وبناء APK

1. أنشئ Repository على GitHub وارفع كل الملفات
2. في GitHub → **Settings → Secrets**, أضف:
   - `EXPO_TOKEN` (من expo.dev → Account → Access Tokens)
3. اذهب لـ **Actions → Build Android APK → Run workflow**
4. انتظر ~15 دقيقة ثم حمّل الـ APK من [expo.dev/builds](https://expo.dev/builds)

### أو البناء اليدوي

```bash
npm install
eas build --platform android --profile preview
```

---

## 📱 مميزات التطبيق

| الميزة | التفاصيل |
|--------|----------|
| 🖊 رسم بيزيه | أداة رسم احترافية بنقاط التحكم |
| 📝 تصدير TTF | خطوط حقيقية قابلة للاستخدام |
| 🌍 متعدد اللغات | عربي + تشكيل + لاتيني + أرقام |
| 📷 كاميرا + معرض | التقط صوراً كمرجع للرسم |
| ☁️ تخزين سحابي | Supabase — آمن ومشفر |
| 🔐 تسجيل Google | OAuth آمن |
| 🛡 لوحة تحكم | إدارة المستخدمين وإشعارات فورية |

---

## 🏗 هيكل المشروع

```
FontCreatorPro/
├── app/
│   ├── _layout.tsx          # Root layout
│   ├── index.tsx            # Entry redirect
│   ├── (auth)/
│   │   ├── login.tsx        # شاشة تسجيل الدخول
│   │   └── banned.tsx       # شاشة الحظر
│   ├── (app)/
│   │   ├── index.tsx        # قائمة الخطوط
│   │   ├── profile.tsx      # الملف الشخصي
│   │   └── editor/
│   │       └── [fontId].tsx # محرر الخط
│   └── admin/
│       └── index.tsx        # لوحة التحكم
├── components/
│   ├── editor/              # مكونات المحرر
│   ├── admin/               # مكونات الإدارة
│   └── ui/                  # مكونات عامة
├── lib/
│   ├── supabase.ts          # Supabase client
│   ├── fontEngine.ts        # توليد TTF
│   └── pushNotifications.ts # إشعارات
├── hooks/
│   ├── useFontStore.ts      # إدارة الخطوط
│   └── useAdmin.ts          # بيانات الإدارة
├── supabase/
│   └── migrations/
│       └── 001_initial.sql  # قاعدة البيانات
└── .github/
    └── workflows/
        └── build.yml        # GitHub Actions
```

---

## 🛡 الأمان

- كل البيانات مخزنة في **Supabase** مع **Row Level Security**
- المستخدمون لا يمكنهم الوصول لبيانات بعضهم
- المشرف فقط يرى كل البيانات
- OAuth عبر Google — لا يُحفظ أي كلمة مرور

---

## 📞 الدعم

تواصل معنا على Telegram: [@BugFreeCode](https://t.me/BugFreeCode)

> **عمر سنجق** و **محمود سنجق** — جميع الحقوق محفوظة 2024
