import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// ─── Types ────────────────────────────────────────────────────────────────────

export type Profile = {
  id: string;
  email: string | null;
  full_name: string | null;
  avatar_url: string | null;
  is_banned: boolean;
  is_admin: boolean;
  push_token: string | null;
  created_at: string;
  last_seen: string;
  device_info: Record<string, any> | null;
};

export type FontRecord = {
  id: string;
  user_id: string;
  name: string;
  glyphs: Record<string, any>;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

export const getProfile = async (userId: string): Promise<Profile | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();
  if (error) return null;
  return data as Profile;
};

export const updateProfile = async (userId: string, updates: Partial<Profile>) => {
  const { error } = await supabase
    .from('profiles')
    .update({ ...updates, last_seen: new Date().toISOString() })
    .eq('id', userId);
  return { error };
};

export const updatePushToken = async (userId: string, token: string) => {
  await supabase.from('profiles').update({ push_token: token }).eq('id', userId);
};

export const getAllProfiles = async (): Promise<Profile[]> => {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  return (data as Profile[]) ?? [];
};

export const banUser = async (userId: string, banned: boolean) => {
  const { error } = await supabase
    .from('profiles')
    .update({ is_banned: banned })
    .eq('id', userId);
  return { error };
};

export const deleteUserAccount = async (userId: string) => {
  const { error } = await supabase.from('profiles').delete().eq('id', userId);
  return { error };
};
