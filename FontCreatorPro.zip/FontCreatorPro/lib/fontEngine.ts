// @ts-ignore
import opentype from 'opentype.js';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { ASCENDER, DESCENDER, UNITS_PER_EM } from '../constants/glyphs';

// ─── Types ────────────────────────────────────────────────────────────────────

export type PathCmd =
  | { type: 'M'; x: number; y: number }
  | { type: 'L'; x: number; y: number }
  | { type: 'C'; x1: number; y1: number; x2: number; y2: number; x: number; y: number }
  | { type: 'Q'; x1: number; y1: number; x: number; y: number }
  | { type: 'Z' };

export type GlyphData = {
  unicode: number;
  char: string;
  advanceWidth: number;
  path: PathCmd[];
};

export type FontMetadata = {
  name: string;
  unitsPerEm: number;
  ascender: number;
  descender: number;
  designer?: string;
  designerUrl?: string;
  license?: string;
  created: string;
};

export type FontProject = {
  id: string;
  name: string;
  metadata: FontMetadata;
  glyphs: Record<string, GlyphData>;
};

// ─── Canvas → Font coordinate transform ───────────────────────────────────────

export const CANVAS_SIZE = 400; // pixels on screen
export const GLYPH_HEIGHT = ASCENDER - DESCENDER; // 1000 units

export function canvasToFont(x: number, y: number, advanceWidth: number): { x: number; y: number } {
  // Canvas: (0,0) top-left. Font: (0,0) baseline center
  return {
    x: (x / CANVAS_SIZE) * advanceWidth,
    y: ASCENDER - (y / CANVAS_SIZE) * GLYPH_HEIGHT,
  };
}

export function fontToCanvas(x: number, y: number, advanceWidth: number): { x: number; y: number } {
  return {
    x: (x / advanceWidth) * CANVAS_SIZE,
    y: ((ASCENDER - y) / GLYPH_HEIGHT) * CANVAS_SIZE,
  };
}

// ─── Build opentype Glyph from our data ───────────────────────────────────────

function buildOpentypePath(cmds: PathCmd[], advanceWidth: number): any {
  const p = new opentype.Path();
  for (const cmd of cmds) {
    if (cmd.type === 'M') {
      const { x, y } = canvasToFont(cmd.x, cmd.y, advanceWidth);
      p.moveTo(x, y);
    } else if (cmd.type === 'L') {
      const { x, y } = canvasToFont(cmd.x, cmd.y, advanceWidth);
      p.lineTo(x, y);
    } else if (cmd.type === 'C') {
      const cp1 = canvasToFont(cmd.x1, cmd.y1, advanceWidth);
      const cp2 = canvasToFont(cmd.x2, cmd.y2, advanceWidth);
      const ep = canvasToFont(cmd.x, cmd.y, advanceWidth);
      p.bezierCurveTo(cp1.x, cp1.y, cp2.x, cp2.y, ep.x, ep.y);
    } else if (cmd.type === 'Q') {
      const cp = canvasToFont(cmd.x1, cmd.y1, advanceWidth);
      const ep = canvasToFont(cmd.x, cmd.y, advanceWidth);
      p.quadraticCurveTo(cp.x, cp.y, ep.x, ep.y);
    } else if (cmd.type === 'Z') {
      p.closePath();
    }
  }
  return p;
}

// ─── Generate TTF ─────────────────────────────────────────────────────────────

export async function generateAndShareTTF(project: FontProject): Promise<void> {
  try {
    // Build glyphs array
    const notdefGlyph = new opentype.Glyph({
      name: '.notdef',
      unicode: 0,
      advanceWidth: 500,
      path: new opentype.Path(),
    });

    const glyphArray = [notdefGlyph];

    for (const [, glyphData] of Object.entries(project.glyphs)) {
      if (glyphData.path.length === 0) continue;
      const opentypePath = buildOpentypePath(glyphData.path, glyphData.advanceWidth);
      const glyph = new opentype.Glyph({
        name: `uni${glyphData.unicode.toString(16).toUpperCase().padStart(4, '0')}`,
        unicode: glyphData.unicode,
        advanceWidth: glyphData.advanceWidth,
        path: opentypePath,
      });
      glyphArray.push(glyph);
    }

    const font = new opentype.Font({
      familyName: project.metadata.name,
      styleName: 'Regular',
      unitsPerEm: project.metadata.unitsPerEm,
      ascender: project.metadata.ascender,
      descender: project.metadata.descender,
      glyphs: glyphArray,
    });

    // Convert to ArrayBuffer then Uint8Array
    const arrayBuffer: ArrayBuffer = font.download
      ? (() => { throw new Error('use arrayBuffer'); })()
      : font.arrayBuffer();

    const uint8 = new Uint8Array(arrayBuffer);
    const base64 = uint8ArrayToBase64(uint8);

    const fileName = `${project.metadata.name.replace(/\s+/g, '_')}.ttf`;
    const fileUri = FileSystem.cacheDirectory + fileName;

    await FileSystem.writeAsStringAsync(fileUri, base64, {
      encoding: FileSystem.EncodingType.Base64,
    });

    const canShare = await Sharing.isAvailableAsync();
    if (canShare) {
      await Sharing.shareAsync(fileUri, {
        mimeType: 'font/ttf',
        dialogTitle: `مشاركة خط ${project.metadata.name}`,
        UTI: 'public.truetype-ttf-font',
      });
    }
  } catch (err) {
    // Fallback: try font.download() browser method via arrayBuffer
    console.error('TTF generation error:', err);
    throw new Error('فشل في إنشاء ملف الخط');
  }
}

function uint8ArrayToBase64(uint8Array: Uint8Array): string {
  let binary = '';
  const len = uint8Array.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(uint8Array[i]);
  }
  return btoa(binary);
}

// ─── Create empty font project ────────────────────────────────────────────────

export function createEmptyProject(name: string): FontProject {
  return {
    id: generateId(),
    name,
    metadata: {
      name,
      unitsPerEm: UNITS_PER_EM,
      ascender: ASCENDER,
      descender: DESCENDER,
      designer: 'Font Creator Pro',
      designerUrl: 'https://t.me/BugFreeCode',
      license: 'Custom',
      created: new Date().toISOString(),
    },
    glyphs: {},
  };
}

export function generateId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}
