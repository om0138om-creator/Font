import { Platform, Dimensions } from 'react-native';
import Constants from 'expo-constants';

export function getDeviceInfo(): Record<string, any> {
  const { width, height } = Dimensions.get('window');
  return {
    platform: Platform.OS,
    version: Platform.Version,
    brand: Constants.deviceName ?? 'unknown',
    appVersion: Constants.expoConfig?.version ?? '1.0.0',
    screen: `${width}x${height}`,
    locale: Constants.expoConfig?.locale ?? 'unknown',
    installedAt: new Date().toISOString(),
  };
}
