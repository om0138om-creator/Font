import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../contexts/AuthContext';
import { Colors } from '../../constants/colors';

export default function BannedScreen() {
  const { signOut, profile } = useAuth();

  return (
    <View style={styles.container}>
      <View style={styles.iconWrap}>
        <Ionicons name="ban" size={64} color={Colors.error} />
      </View>
      <Text style={styles.title}>تم حظر حسابك</Text>
      <Text style={styles.sub}>
        تم تقييد وصولك إلى Font Creator Pro.{'\n'}
        إذا كنت تعتقد أن هذا خطأ، تواصل مع الدعم.
      </Text>

      <TouchableOpacity style={styles.supportBtn} onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
        <Ionicons name="logo-telegram" size={20} color={Colors.text} />
        <Text style={styles.supportText}>تواصل مع الدعم</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.signOutBtn} onPress={signOut}>
        <Text style={styles.signOutText}>تسجيل الخروج</Text>
      </TouchableOpacity>

      <View style={styles.credits}>
        <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
          <Text style={styles.creditsName}>عمر سنجق</Text>
        </TouchableOpacity>
        <Text style={styles.creditsText}> و </Text>
        <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
          <Text style={styles.creditsName}>محمود سنجق</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg, justifyContent: 'center', alignItems: 'center', padding: 32 },
  iconWrap: {
    width: 120, height: 120, borderRadius: 36,
    backgroundColor: Colors.error + '15',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: Colors.error + '30',
    marginBottom: 28,
  },
  title: { color: Colors.text, fontSize: 24, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
  sub: { color: Colors.textSub, fontSize: 15, textAlign: 'center', lineHeight: 22, marginBottom: 32 },
  supportBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.primary, borderRadius: 14,
    paddingVertical: 14, paddingHorizontal: 28, marginBottom: 12,
  },
  supportText: { color: Colors.text, fontSize: 15, fontWeight: '700' },
  signOutBtn: { paddingVertical: 12, paddingHorizontal: 24 },
  signOutText: { color: Colors.textSub, fontSize: 14 },
  credits: { flexDirection: 'row', marginTop: 48, alignItems: 'center' },
  creditsText: { color: Colors.textMuted, fontSize: 12 },
  creditsName: { color: Colors.adminRed, fontSize: 12, fontWeight: '700' },
});
