import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image,
  Dimensions, Linking, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../contexts/AuthContext';
import { Colors } from '../../constants/colors';

const { width, height } = Dimensions.get('window');

export default function LoginScreen() {
  const { signInWithGoogle } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleGoogle = async () => {
    setLoading(true);
    try { await signInWithGoogle(); }
    finally { setLoading(false); }
  };

  return (
    <View style={styles.root}>
      {/* Background blobs */}
      <View style={[styles.blob, styles.blob1]} />
      <View style={[styles.blob, styles.blob2]} />
      <View style={[styles.blob, styles.blob3]} />

      <View style={styles.content}>
        {/* Logo */}
        <View style={styles.logoWrap}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoEmoji}>✍️</Text>
          </View>
          <Text style={styles.logoTitle}>Font Creator Pro</Text>
          <Text style={styles.logoSub}>صانع الخطوط الاحترافي</Text>
        </View>

        {/* Features */}
        <View style={styles.features}>
          {FEATURES.map((f, i) => (
            <View key={i} style={styles.featureRow}>
              <View style={styles.featureIcon}>
                <Ionicons name={f.icon as any} size={18} color={Colors.primary} />
              </View>
              <View>
                <Text style={styles.featureTitle}>{f.title}</Text>
                <Text style={styles.featureSub}>{f.sub}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Google Sign In */}
        <TouchableOpacity style={styles.googleBtn} onPress={handleGoogle} disabled={loading} activeOpacity={0.85}>
          {loading ? (
            <ActivityIndicator color={Colors.text} />
          ) : (
            <>
              <View style={styles.googleIconWrap}>
                <Text style={styles.googleG}>G</Text>
              </View>
              <Text style={styles.googleText}>تسجيل الدخول بـ Google</Text>
            </>
          )}
        </TouchableOpacity>

        <Text style={styles.termsText}>
          بالتسجيل، توافق على{' '}
          <Text style={styles.termsLink} onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
            شروط الاستخدام
          </Text>
        </Text>

        {/* Credits */}
        <View style={styles.credits}>
          <Text style={styles.creditsText}>تم التصميم بواسطة </Text>
          <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
            <Text style={styles.creditsName}>عمر سنجق</Text>
          </TouchableOpacity>
          <Text style={styles.creditsText}> و </Text>
          <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
            <Text style={styles.creditsName}>محمود سنجق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const FEATURES = [
  { icon: 'brush', title: 'رسم احترافي', sub: 'أداة بيزيه متطورة لرسم الحروف بدقة' },
  { icon: 'document-text', title: 'تصدير TTF', sub: 'صادر خطك كملف TTF جاهز للاستخدام' },
  { icon: 'globe', title: 'دعم متعدد اللغات', sub: 'عربي، لاتيني، أرقام، وتشكيل' },
  { icon: 'lock-closed', title: 'تخزين آمن', sub: 'بياناتك محفوظة ومشفرة على السحابة' },
];

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  blob: { position: 'absolute', borderRadius: 999 },
  blob1: { width: 300, height: 300, backgroundColor: Colors.primary + '15', top: -80, right: -80 },
  blob2: { width: 200, height: 200, backgroundColor: Colors.secondary + '10', bottom: 100, left: -60 },
  blob3: { width: 150, height: 150, backgroundColor: Colors.accent + '0A', top: height * 0.4, right: 20 },
  content: { flex: 1, paddingHorizontal: 28, justifyContent: 'center', paddingBottom: 40 },
  logoWrap: { alignItems: 'center', marginBottom: 40 },
  logoCircle: {
    width: 90, height: 90, borderRadius: 28,
    backgroundColor: Colors.primary + '20',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: Colors.primary + '40',
    marginBottom: 16,
  },
  logoEmoji: { fontSize: 40 },
  logoTitle: { color: Colors.text, fontSize: 26, fontWeight: '800', letterSpacing: 0.5 },
  logoSub: { color: Colors.textSub, fontSize: 15, marginTop: 4 },
  features: { marginBottom: 40, gap: 16 },
  featureRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 14 },
  featureIcon: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: Colors.primary + '15',
    justifyContent: 'center', alignItems: 'center',
  },
  featureTitle: { color: Colors.text, fontSize: 14, fontWeight: '700' },
  featureSub: { color: Colors.textSub, fontSize: 12, marginTop: 2 },
  googleBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: Colors.primary, borderRadius: 16,
    paddingVertical: 16, gap: 12,
    shadowColor: Colors.primary, shadowOpacity: 0.4, shadowRadius: 20, shadowOffset: { width: 0, height: 8 },
    elevation: 10,
  },
  googleIconWrap: {
    width: 28, height: 28, borderRadius: 8,
    backgroundColor: Colors.text, justifyContent: 'center', alignItems: 'center',
  },
  googleG: { color: Colors.primary, fontSize: 16, fontWeight: '900' },
  googleText: { color: Colors.text, fontSize: 16, fontWeight: '700' },
  termsText: { color: Colors.textMuted, fontSize: 12, textAlign: 'center', marginTop: 16 },
  termsLink: { color: Colors.primary },
  credits: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 32, flexWrap: 'wrap' },
  creditsText: { color: Colors.textMuted, fontSize: 12 },
  creditsName: { color: Colors.adminRed, fontSize: 12, fontWeight: '700' },
});
