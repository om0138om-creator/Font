import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import * as Linking from 'expo-linking';
import { supabase } from '../../lib/supabase';
import { Colors } from '../../constants/colors';

export default function AuthCallback() {
  const router = useRouter();

  useEffect(() => {
    const url = Linking.useURL();
    if (!url) return;

    const handleCallback = async () => {
      try {
        const parsed = Linking.parse(url);
        const params = parsed.queryParams as Record<string, string> | null;

        if (params?.access_token && params?.refresh_token) {
          await supabase.auth.setSession({
            access_token: params.access_token,
            refresh_token: params.refresh_token,
          });
        }
      } catch {}
      router.replace('/');
    };

    handleCallback();
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: Colors.bg, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator color={Colors.primary} size="large" />
    </View>
  );
}
