import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Alert, Linking, RefreshControl, Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../contexts/AuthContext';
import { useFontStore } from '../../hooks/useFontStore';
import { FontProject } from '../../lib/fontEngine';
import { generateAndShareTTF } from '../../lib/fontEngine';
import { Colors } from '../../constants/colors';
import { Loading } from '../../components/ui/Loading';

export default function HomeScreen() {
  const { session, profile, isAdmin, signOut } = useAuth();
  const { fonts, loading, loadFonts, createFont, deleteFont } = useFontStore();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [exporting, setExporting] = useState<string | null>(null);

  useEffect(() => {
    if (session) loadFonts(session.user.id);
  }, [session]);

  const handleCreate = async () => {
    if (!newName.trim() || !session) return;
    setCreating(true);
    try {
      const font = await createFont(session.user.id, newName.trim());
      setNewName('');
      setShowCreate(false);
      router.push({ pathname: '/(app)/editor/[fontId]', params: { fontId: font.id } });
    } catch (e: any) {
      Alert.alert('خطأ', e.message);
    } finally {
      setCreating(false);
    }
  };

  const handleExport = async (font: FontProject) => {
    setExporting(font.id);
    try { await generateAndShareTTF(font); }
    catch (e: any) { Alert.alert('خطأ في التصدير', e.message); }
    finally { setExporting(null); }
  };

  const handleDelete = (font: FontProject) => {
    Alert.alert('حذف الخط', `هل تريد حذف "${font.name}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => deleteFont(font.id) },
    ]);
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>مرحباً، {profile?.full_name?.split(' ')[0] ?? 'مصمم'} 👋</Text>
          <Text style={styles.subGreeting}>خطوطك الإبداعية</Text>
        </View>
        <View style={styles.headerRight}>
          {isAdmin && (
            <TouchableOpacity style={styles.adminBtn} onPress={() => router.push('/admin')}>
              <Ionicons name="shield" size={22} color={Colors.primary} />
            </TouchableOpacity>
          )}
          <TouchableOpacity style={styles.avatarBtn} onPress={signOut}>
            <Ionicons name="person-circle" size={32} color={Colors.textSub} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Font count */}
      <View style={styles.countRow}>
        <Text style={styles.countText}>{fonts.length} خط</Text>
        <TouchableOpacity style={styles.createFAB} onPress={() => setShowCreate(true)}>
          <Ionicons name="add" size={20} color={Colors.text} />
          <Text style={styles.createText}>خط جديد</Text>
        </TouchableOpacity>
      </View>

      {/* Font list */}
      {loading ? (
        <View style={styles.loadingWrap}><Loading size={40} /></View>
      ) : (
        <FlatList
          data={fonts}
          keyExtractor={f => f.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={loading}
              onRefresh={() => session && loadFonts(session.user.id)}
              tintColor={Colors.primary}
            />
          }
          ListEmptyComponent={<EmptyState onCreate={() => setShowCreate(true)} />}
          renderItem={({ item: font }) => (
            <FontCard
              font={font}
              onEdit={() => router.push({ pathname: '/(app)/editor/[fontId]', params: { fontId: font.id } })}
              onExport={() => handleExport(font)}
              onDelete={() => handleDelete(font)}
              exporting={exporting === font.id}
            />
          )}
        />
      )}

      {/* Credits footer */}
      <View style={[styles.credits, { paddingBottom: insets.bottom + 8 }]}>
        <Text style={styles.creditsTxt}>تصميم </Text>
        <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
          <Text style={styles.creditsName}>عمر سنجق</Text>
        </TouchableOpacity>
        <Text style={styles.creditsTxt}> و </Text>
        <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
          <Text style={styles.creditsName}>محمود سنجق</Text>
        </TouchableOpacity>
      </View>

      {/* Create Modal */}
      <Modal visible={showCreate} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>إنشاء خط جديد</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="اسم الخط (مثال: خطي العربي)"
              placeholderTextColor={Colors.textMuted}
              value={newName}
              onChangeText={setNewName}
              autoFocus
              textAlign="right"
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => { setShowCreate(false); setNewName(''); }}>
                <Text style={styles.cancelText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.confirmBtn, (!newName.trim() || creating) && styles.disabledBtn]}
                onPress={handleCreate}
                disabled={!newName.trim() || creating}
              >
                <Text style={styles.confirmText}>{creating ? '...' : 'إنشاء'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function FontCard({ font, onEdit, onExport, onDelete, exporting }: {
  font: FontProject;
  onEdit: () => void;
  onExport: () => void;
  onDelete: () => void;
  exporting: boolean;
}) {
  const count = Object.keys(font.glyphs).length;
  const updated = new Date(font.metadata.created).toLocaleDateString('ar');

  return (
    <TouchableOpacity style={styles.card} onPress={onEdit} activeOpacity={0.85}>
      <View style={styles.cardLeft}>
        <View style={styles.fontIcon}>
          <Text style={styles.fontIconText}>{font.name[0]?.toUpperCase() ?? 'F'}</Text>
        </View>
        <View>
          <Text style={styles.fontName}>{font.name}</Text>
          <Text style={styles.fontMeta}>{count} رمز · {updated}</Text>
        </View>
      </View>
      <View style={styles.cardActions}>
        <TouchableOpacity style={styles.actionIcon} onPress={onExport} disabled={exporting}>
          {exporting ? <Loading size={18} /> : <Ionicons name="share-outline" size={18} color={Colors.accent} />}
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionIcon} onPress={onDelete}>
          <Ionicons name="trash-outline" size={18} color={Colors.error} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

function EmptyState({ onCreate }: { onCreate: () => void }) {
  return (
    <View style={styles.empty}>
      <Text style={styles.emptyIcon}>✍️</Text>
      <Text style={styles.emptyTitle}>لا توجد خطوط بعد</Text>
      <Text style={styles.emptySubtitle}>ابدأ بإنشاء أول خط إبداعي لك</Text>
      <TouchableOpacity style={styles.emptyBtn} onPress={onCreate}>
        <Text style={styles.emptyBtnText}>إنشاء خط جديد</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start',
    paddingHorizontal: 20, paddingVertical: 16,
  },
  greeting: { color: Colors.text, fontSize: 22, fontWeight: '800' },
  subGreeting: { color: Colors.textSub, fontSize: 14, marginTop: 2 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  adminBtn: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: Colors.primary + '20',
    justifyContent: 'center', alignItems: 'center',
  },
  avatarBtn: { padding: 4 },
  countRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, marginBottom: 12,
  },
  countText: { color: Colors.textSub, fontSize: 14, fontWeight: '600' },
  createFAB: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.primary, borderRadius: 14,
    paddingHorizontal: 16, paddingVertical: 10,
  },
  createText: { color: Colors.text, fontWeight: '700', fontSize: 14 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  list: { paddingHorizontal: 16, paddingBottom: 16, gap: 10 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 16, padding: 16,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  cardLeft: { flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 },
  fontIcon: {
    width: 48, height: 48, borderRadius: 14,
    backgroundColor: Colors.primary + '20',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.primary + '40',
  },
  fontIconText: { color: Colors.primary, fontSize: 22, fontWeight: '800' },
  fontName: { color: Colors.text, fontSize: 16, fontWeight: '700' },
  fontMeta: { color: Colors.textSub, fontSize: 12, marginTop: 2 },
  cardActions: { flexDirection: 'row', gap: 4 },
  actionIcon: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: Colors.surfaceAlt,
    justifyContent: 'center', alignItems: 'center',
  },
  empty: { alignItems: 'center', paddingTop: 80, paddingHorizontal: 32 },
  emptyIcon: { fontSize: 56, marginBottom: 16 },
  emptyTitle: { color: Colors.text, fontSize: 20, fontWeight: '700', marginBottom: 8 },
  emptySubtitle: { color: Colors.textSub, fontSize: 14, textAlign: 'center', marginBottom: 28 },
  emptyBtn: { backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 14, paddingHorizontal: 28 },
  emptyBtnText: { color: Colors.text, fontWeight: '700', fontSize: 15 },
  credits: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingTop: 8 },
  creditsTxt: { color: Colors.textMuted, fontSize: 11 },
  creditsName: { color: Colors.adminRed, fontSize: 11, fontWeight: '700' },
  modalOverlay: { flex: 1, backgroundColor: '#00000080', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalTitle: { color: Colors.text, fontSize: 18, fontWeight: '800', marginBottom: 16, textAlign: 'center' },
  modalInput: {
    backgroundColor: Colors.surfaceAlt, borderRadius: 12, padding: 14,
    color: Colors.text, fontSize: 16, borderWidth: 1, borderColor: Colors.border, marginBottom: 16,
  },
  modalBtns: { flexDirection: 'row', gap: 12 },
  cancelBtn: {
    flex: 1, backgroundColor: Colors.surfaceAlt, borderRadius: 14,
    paddingVertical: 14, alignItems: 'center',
  },
  cancelText: { color: Colors.textSub, fontWeight: '700' },
  confirmBtn: { flex: 1, backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  confirmText: { color: Colors.text, fontWeight: '700', fontSize: 15 },
  disabledBtn: { opacity: 0.5 },
});
