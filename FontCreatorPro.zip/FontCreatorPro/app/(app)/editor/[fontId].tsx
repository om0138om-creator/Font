import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, Modal, TouchableOpacity,
  Alert, Dimensions, ScrollView,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Camera from 'expo-camera';
import { useFontStore } from '../../../hooks/useFontStore';
import { generateAndShareTTF, GlyphData, PathCmd, CANVAS_SIZE } from '../../../lib/fontEngine';
import { BezierCanvas } from '../../../components/editor/BezierCanvas';
import { GlyphGrid } from '../../../components/editor/GlyphGrid';
import { FontPreview } from '../../../components/editor/FontPreview';
import { ToolBar, Tool } from '../../../components/editor/ToolBar';
import { Loading } from '../../../components/ui/Loading';
import { Colors } from '../../../constants/colors';

type Tab = 'glyphs' | 'preview';

export default function FontEditorScreen() {
  const { fontId } = useLocalSearchParams<{ fontId: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { fonts, setActiveFont, activeFont, updateGlyph } = useFontStore();

  const [tab, setTab] = useState<Tab>('glyphs');
  const [editingChar, setEditingChar] = useState<string | null>(null);
  const [activeTool, setActiveTool] = useState<Tool>('pen');
  const [currentPath, setCurrentPath] = useState<PathCmd[]>([]);
  const [exporting, setExporting] = useState(false);

  // Undo/redo history
  const [history, setHistory] = useState<PathCmd[][]>([[]]);
  const [histIdx, setHistIdx] = useState(0);

  useEffect(() => {
    const font = fonts.find(f => f.id === fontId);
    if (font) setActiveFont(font);
    else router.back();
  }, [fontId, fonts]);

  const font = activeFont;
  if (!font) return <View style={styles.root}><Loading size={40} /></View>;

  // ─── Glyph editing ────────────────────────────────────────────────────────

  const openGlyph = (char: string) => {
    const existing = font.glyphs[char];
    const path = existing?.path ?? [];
    setCurrentPath(path);
    setHistory([path]);
    setHistIdx(0);
    setEditingChar(char);
  };

  const handlePathChange = (cmds: PathCmd[]) => {
    setCurrentPath(cmds);
  };

  const saveGlyph = async () => {
    if (!editingChar) return;
    const glyph: GlyphData = {
      unicode: editingChar.codePointAt(0) ?? 0,
      char: editingChar,
      advanceWidth: 600,
      path: currentPath,
    };
    await updateGlyph(font.id, glyph);
    setEditingChar(null);
  };

  const handleUndo = () => {
    const ni = Math.max(0, histIdx - 1);
    setHistIdx(ni);
    setCurrentPath(history[ni]);
  };

  const handleRedo = () => {
    const ni = Math.min(history.length - 1, histIdx + 1);
    setHistIdx(ni);
    setCurrentPath(history[ni]);
  };

  const handleClear = () => {
    Alert.alert('مسح الحرف', 'هل تريد مسح رسم هذا الحرف؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مسح', style: 'destructive', onPress: () => {
        setCurrentPath([]);
        const newHist = [...history.slice(0, histIdx + 1), []];
        setHistory(newHist);
        setHistIdx(newHist.length - 1);
      }},
    ]);
  };

  // ─── Camera / Gallery for reference ───────────────────────────────────────

  const pickFromGallery = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { Alert.alert('تحتاج إذن الوصول للمعرض'); return; }
    await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 1 });
  };

  const pickFromCamera = async () => {
    const { status } = await Camera.Camera.requestCameraPermissionsAsync();
    if (status !== 'granted') { Alert.alert('تحتاج إذن الكاميرا'); return; }
    await ImagePicker.launchCameraAsync({ quality: 1 });
  };

  // ─── Export ───────────────────────────────────────────────────────────────

  const handleExport = async () => {
    setExporting(true);
    try { await generateAndShareTTF(font); }
    catch (e: any) { Alert.alert('خطأ', e.message); }
    finally { setExporting(false); }
  };

  // ─── Render ───────────────────────────────────────────────────────────────

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={Colors.text} />
        </TouchableOpacity>
        <View style={styles.headerTitle}>
          <Text style={styles.title} numberOfLines={1}>{font.name}</Text>
          <Text style={styles.subtitle}>{Object.keys(font.glyphs).length} حرف مرسوم</Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.iconBtn} onPress={pickFromGallery}>
            <Ionicons name="images-outline" size={20} color={Colors.textSub} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={pickFromCamera}>
            <Ionicons name="camera-outline" size={20} color={Colors.textSub} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.iconBtn, styles.exportBtn]} onPress={handleExport} disabled={exporting}>
            {exporting ? <Loading size={18} /> : <Ionicons name="share-outline" size={20} color={Colors.text} />}
          </TouchableOpacity>
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        {(['glyphs', 'preview'] as Tab[]).map(t => (
          <TouchableOpacity key={t} style={[styles.tab, tab === t && styles.tabActive]} onPress={() => setTab(t)}>
            <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>
              {t === 'glyphs' ? 'الحروف' : 'المعاينة'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Content */}
      {tab === 'glyphs' ? (
        <GlyphGrid font={font} onSelectChar={openGlyph} />
      ) : (
        <FontPreview font={font} />
      )}

      {/* Glyph Editor Modal */}
      <Modal visible={editingChar !== null} animationType="slide" statusBarTranslucent>
        <View style={[styles.editorModal, { paddingTop: insets.top }]}>
          {/* Char header */}
          <View style={styles.editorHeader}>
            <TouchableOpacity onPress={() => setEditingChar(null)}>
              <Ionicons name="close" size={24} color={Colors.text} />
            </TouchableOpacity>
            <View style={styles.charInfo}>
              <Text style={styles.charDisplay}>{editingChar}</Text>
              <Text style={styles.charCode}>
                U+{editingChar?.codePointAt(0)?.toString(16).toUpperCase().padStart(4, '0')}
              </Text>
            </View>
            <TouchableOpacity style={styles.newContourBtn} onPress={() => {
              const sep: PathCmd = { type: 'M', x: 50, y: 50 };
              setCurrentPath(prev => [...prev]);
            }}>
              <Ionicons name="add-circle-outline" size={22} color={Colors.primary} />
            </TouchableOpacity>
          </View>

          {/* Canvas */}
          <ScrollView contentContainerStyle={styles.canvasWrap} showsVerticalScrollIndicator={false}>
            <BezierCanvas
              initialPath={currentPath}
              tool={activeTool}
              onPathChange={handlePathChange}
              char={editingChar ?? ''}
            />
            <Text style={styles.canvasHint}>
              {activeTool === 'pen'
                ? '🖊 انقر لإضافة نقطة • اضغط طويلاً على نقطة لإضافة مقبض بيزيه • اقترب من أول نقطة لإغلاق الشكل'
                : activeTool === 'select'
                ? '☝️ اسحب النقاط أو المقابض للتعديل'
                : '🗑 انقر على نقطة لمسحها'}
            </Text>
          </ScrollView>

          {/* Toolbar */}
          <ToolBar
            activeTool={activeTool}
            onToolChange={setActiveTool}
            onUndo={handleUndo}
            onRedo={handleRedo}
            onClear={handleClear}
            onClose={saveGlyph}
            canUndo={histIdx > 0}
            canRedo={histIdx < history.length - 1}
          />
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  backBtn: { padding: 4 },
  headerTitle: { flex: 1 },
  title: { color: Colors.text, fontSize: 17, fontWeight: '700' },
  subtitle: { color: Colors.textSub, fontSize: 12, marginTop: 1 },
  headerActions: { flexDirection: 'row', gap: 6 },
  iconBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: Colors.surfaceAlt,
    justifyContent: 'center', alignItems: 'center',
  },
  exportBtn: { backgroundColor: Colors.primary },
  tabs: {
    flexDirection: 'row',
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: Colors.primary },
  tabText: { color: Colors.textMuted, fontSize: 14, fontWeight: '600' },
  tabTextActive: { color: Colors.primary },

  // Editor modal
  editorModal: { flex: 1, backgroundColor: Colors.bg },
  editorHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  charInfo: { alignItems: 'center' },
  charDisplay: { color: Colors.text, fontSize: 36, fontWeight: '700', lineHeight: 44 },
  charCode: { color: Colors.textMuted, fontSize: 11 },
  newContourBtn: { padding: 4 },
  canvasWrap: { alignItems: 'center', padding: 16, gap: 12 },
  canvasHint: {
    color: Colors.textMuted, fontSize: 12, textAlign: 'center',
    lineHeight: 18, paddingHorizontal: 16,
  },
});
