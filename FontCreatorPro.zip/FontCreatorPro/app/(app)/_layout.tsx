import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';
import { useAuth } from '../../contexts/AuthContext';

export default function AppLayout() {
  const { isAdmin } = useAuth();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: Colors.surface,
          borderTopColor: Colors.border,
          borderTopWidth: 1,
          height: 62,
          paddingBottom: 8,
        },
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: Colors.textMuted,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'خطوطي',
          tabBarIcon: ({ color, size }) => <Ionicons name="text" size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="editor"
        options={{
          href: null, // Hidden from tab bar, opened programmatically
        }}
      />
      {isAdmin && (
        <Tabs.Screen
          name="../../admin/index"
          options={{
            title: 'لوحة التحكم',
            tabBarIcon: ({ color, size }) => <Ionicons name="shield" size={size} color={color} />,
          }}
        />
      )}
      <Tabs.Screen
        name="profile"
        options={{
          title: 'حسابي',
          tabBarIcon: ({ color, size }) => <Ionicons name="person" size={size} color={color} />,
        }}
      />
    </Tabs>
  );
}
