import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Linking, Alert, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../contexts/AuthContext';
import { useFontStore } from '../../hooks/useFontStore';
import { Colors } from '../../constants/colors';

export default function ProfileScreen() {
  const { profile, signOut, isAdmin } = useAuth();
  const { fonts } = useFontStore();
  const insets = useSafeAreaInsets();

  const handleSignOut = () => {
    Alert.alert('تسجيل الخروج', 'هل تريد تسجيل الخروج؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'خروج', style: 'destructive', onPress: signOut },
    ]);
  };

  const totalGlyphs = fonts.reduce((sum, f) => sum + Object.keys(f.glyphs).length, 0);
  const joinDate = profile?.created_at
    ? new Date(profile.created_at).toLocaleDateString('ar', { year: 'numeric', month: 'long', day: 'numeric' })
    : '';

  return (
    <ScrollView style={[styles.root, { paddingTop: insets.top }]} showsVerticalScrollIndicator={false}>
      {/* Profile card */}
      <View style={styles.profileCard}>
        {profile?.avatar_url ? (
          <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
        ) : (
          <View style={[styles.avatar, styles.avatarFallback]}>
            <Text style={styles.avatarLetter}>{(profile?.full_name ?? 'U')[0].toUpperCase()}</Text>
          </View>
        )}
        <Text style={styles.name}>{profile?.full_name ?? 'مستخدم'}</Text>
        <Text style={styles.email}>{profile?.email}</Text>
        {isAdmin && (
          <View style={styles.adminBadge}>
            <Ionicons name="shield-checkmark" size={14} color={Colors.primary} />
            <Text style={styles.adminText}>مشرف</Text>
          </View>
        )}
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.stat}>
          <Text style={styles.statNum}>{fonts.length}</Text>
          <Text style={styles.statLabel}>خط</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.stat}>
          <Text style={styles.statNum}>{totalGlyphs}</Text>
          <Text style={styles.statLabel}>رمز</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.stat}>
          <Text style={styles.statNum}>{joinDate.split(' ')[2] ?? '–'}</Text>
          <Text style={styles.statLabel}>منذ</Text>
        </View>
      </View>

      {/* Menu */}
      <View style={styles.menu}>
        {MENU_ITEMS.map((item, i) => (
          <TouchableOpacity
            key={i}
            style={styles.menuItem}
            onPress={() => {
              if (item.url) Linking.openURL(item.url);
              if (item.action === 'signout') handleSignOut();
            }}
          >
            <View style={[styles.menuIcon, { backgroundColor: item.color + '20' }]}>
              <Ionicons name={item.icon as any} size={20} color={item.color} />
            </View>
            <Text style={styles.menuLabel}>{item.label}</Text>
            <Ionicons name="chevron-back" size={16} color={Colors.textMuted} />
          </TouchableOpacity>
        ))}
      </View>

      {/* Credits */}
      <View style={styles.credits}>
        <Text style={styles.creditsTxt}>Font Creator Pro</Text>
        <Text style={styles.creditsVersion}>الإصدار 1.0.0</Text>
        <View style={styles.creditsByRow}>
          <Text style={styles.creditsByTxt}>تصميم </Text>
          <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
            <Text style={styles.creditsName}>عمر سنجق</Text>
          </TouchableOpacity>
          <Text style={styles.creditsByTxt}> و </Text>
          <TouchableOpacity onPress={() => Linking.openURL('https://t.me/BugFreeCode')}>
            <Text style={styles.creditsName}>محمود سنجق</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const MENU_ITEMS = [
  { icon: 'logo-telegram', label: 'قناتنا على تيليجرام', color: Colors.primary, url: 'https://t.me/BugFreeCode' },
  { icon: 'help-circle-outline', label: 'المساعدة والدعم', color: Colors.accent, url: 'https://t.me/BugFreeCode' },
  { icon: 'shield-outline', label: 'سياسة الخصوصية', color: Colors.textSub, url: 'https://t.me/BugFreeCode' },
  { icon: 'log-out-outline', label: 'تسجيل الخروج', color: Colors.error, action: 'signout' },
];

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  profileCard: { alignItems: 'center', paddingVertical: 32, paddingHorizontal: 24 },
  avatar: { width: 88, height: 88, borderRadius: 28, marginBottom: 14 },
  avatarFallback: { backgroundColor: Colors.primary + '20', justifyContent: 'center', alignItems: 'center' },
  avatarLetter: { color: Colors.primary, fontSize: 36, fontWeight: '800' },
  name: { color: Colors.text, fontSize: 22, fontWeight: '800', marginBottom: 4 },
  email: { color: Colors.textSub, fontSize: 14, marginBottom: 10 },
  adminBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.primary + '20', borderRadius: 10,
    paddingHorizontal: 10, paddingVertical: 4,
  },
  adminText: { color: Colors.primary, fontSize: 12, fontWeight: '700' },
  statsRow: {
    flexDirection: 'row', backgroundColor: Colors.surface,
    marginHorizontal: 16, borderRadius: 16, borderWidth: 1, borderColor: Colors.border,
    paddingVertical: 16, marginBottom: 16,
  },
  stat: { flex: 1, alignItems: 'center' },
  statNum: { color: Colors.text, fontSize: 22, fontWeight: '800' },
  statLabel: { color: Colors.textSub, fontSize: 12, marginTop: 2 },
  statDivider: { width: 1, backgroundColor: Colors.border },
  menu: { marginHorizontal: 16, gap: 8 },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    backgroundColor: Colors.surface, borderRadius: 14,
    padding: 14, borderWidth: 1, borderColor: Colors.border,
  },
  menuIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  menuLabel: { flex: 1, color: Colors.text, fontSize: 15, fontWeight: '600' },
  credits: { alignItems: 'center', paddingVertical: 32 },
  creditsTxt: { color: Colors.textSub, fontSize: 14, fontWeight: '700' },
  creditsVersion: { color: Colors.textMuted, fontSize: 12, marginTop: 2, marginBottom: 8 },
  creditsByRow: { flexDirection: 'row', alignItems: 'center' },
  creditsByTxt: { color: Colors.textMuted, fontSize: 12 },
  creditsName: { color: Colors.adminRed, fontSize: 12, fontWeight: '700' },
});
