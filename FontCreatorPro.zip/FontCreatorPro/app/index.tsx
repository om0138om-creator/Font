import { Redirect } from 'expo-router';
import { useAuth } from '../contexts/AuthContext';
import { FullScreenLoading } from '../components/ui/Loading';

export default function Index() {
  const { session, loading, isBanned, isAdmin } = useAuth();

  if (loading) return <FullScreenLoading />;
  if (!session) return <Redirect href="/(auth)/login" />;
  if (isBanned) return <Redirect href="/(auth)/banned" />;
  return <Redirect href="/(app)" />;
}
