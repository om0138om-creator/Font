import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, FlatList,
  TouchableOpacity, TextInput, RefreshControl, Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth } from '../../contexts/AuthContext';
import { useAdmin } from '../../hooks/useAdmin';
import { UserCard } from '../../components/admin/UserCard';
import { StatsCard } from '../../components/admin/StatsCard';
import { Colors } from '../../constants/colors';
import { Redirect } from 'expo-router';

export default function AdminDashboard() {
  const { isAdmin } = useAuth();
  if (!isAdmin) return <Redirect href="/(app)" />;

  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { users, stats, loading, newUserAlert, loadData, handleBan, handleDelete } = useAdmin(isAdmin);

  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'banned' | 'active'>('all');

  const filtered = users.filter(u => {
    const matchSearch =
      !search ||
      u.email?.toLowerCase().includes(search.toLowerCase()) ||
      u.full_name?.toLowerCase().includes(search.toLowerCase());
    const matchFilter =
      filter === 'all' ||
      (filter === 'banned' && u.is_banned) ||
      (filter === 'active' && !u.is_banned);
    return matchSearch && matchFilter;
  });

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={24} color={Colors.text} />
        </TouchableOpacity>
        <View>
          <Text style={styles.title}>لوحة التحكم</Text>
          <Text style={styles.subtitle}>مرحباً بك، مشرف</Text>
        </View>
        <TouchableOpacity style={styles.refreshBtn} onPress={loadData}>
          <Ionicons name="refresh" size={20} color={Colors.primary} />
        </TouchableOpacity>
      </View>

      {/* New user alert banner */}
      {newUserAlert && (
        <View style={styles.alertBanner}>
          <Ionicons name="person-add" size={18} color={Colors.text} />
          <Text style={styles.alertText}>
            مستخدم جديد: {newUserAlert.full_name ?? newUserAlert.email}
          </Text>
          <View style={styles.alertDot} />
        </View>
      )}

      <ScrollView showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={loadData} tintColor={Colors.primary} />}
      >
        {/* Stats */}
        <View style={styles.statsGrid}>
          <View style={styles.statsRow}>
            <StatsCard icon="people" label="إجمالي المستخدمين" value={stats.totalUsers} color={Colors.primary} />
            <StatsCard icon="pulse" label="نشط اليوم" value={stats.activeToday} color={Colors.accent} />
          </View>
          <View style={styles.statsRow}>
            <StatsCard icon="ban" label="محظور" value={stats.bannedUsers} color={Colors.error} />
            <StatsCard icon="text" label="إجمالي الخطوط" value={stats.totalFonts} color={Colors.secondary} />
          </View>
        </View>

        {/* Search & filter */}
        <View style={styles.searchSection}>
          <View style={styles.searchBar}>
            <Ionicons name="search" size={16} color={Colors.textMuted} />
            <TextInput
              style={styles.searchInput}
              placeholder="بحث عن مستخدم..."
              placeholderTextColor={Colors.textMuted}
              value={search}
              onChangeText={setSearch}
            />
            {search ? (
              <TouchableOpacity onPress={() => setSearch('')}>
                <Ionicons name="close-circle" size={16} color={Colors.textMuted} />
              </TouchableOpacity>
            ) : null}
          </View>

          <View style={styles.filterRow}>
            {(['all', 'active', 'banned'] as const).map(f => (
              <TouchableOpacity
                key={f}
                style={[styles.filterBtn, filter === f && styles.filterBtnActive]}
                onPress={() => setFilter(f)}
              >
                <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
                  {f === 'all' ? 'الكل' : f === 'active' ? 'نشط' : 'محظور'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Users list */}
        <View style={styles.usersList}>
          <Text style={styles.sectionTitle}>
            المستخدمون ({filtered.length})
          </Text>
          {filtered.map(user => (
            <UserCard
              key={user.id}
              user={user}
              onBan={handleBan}
              onDelete={handleDelete}
            />
          ))}
          {filtered.length === 0 && (
            <View style={styles.empty}>
              <Ionicons name="people-outline" size={40} color={Colors.textMuted} />
              <Text style={styles.emptyText}>لا يوجد مستخدمون</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 16, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    backgroundColor: Colors.surface,
  },
  backBtn: { padding: 4 },
  title: { color: Colors.text, fontSize: 18, fontWeight: '800' },
  subtitle: { color: Colors.textSub, fontSize: 12 },
  refreshBtn: {
    marginLeft: 'auto', width: 38, height: 38, borderRadius: 10,
    backgroundColor: Colors.primary + '20', justifyContent: 'center', alignItems: 'center',
  },
  alertBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.success + '20',
    borderBottomWidth: 1, borderBottomColor: Colors.success + '40',
    paddingHorizontal: 16, paddingVertical: 10,
  },
  alertText: { flex: 1, color: Colors.success, fontSize: 13, fontWeight: '600' },
  alertDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.success },
  statsGrid: { padding: 16, gap: 10 },
  statsRow: { flexDirection: 'row', gap: 10 },
  searchSection: { paddingHorizontal: 16, marginBottom: 8, gap: 10 },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.surface, borderRadius: 12,
    paddingHorizontal: 12, paddingVertical: 10,
    borderWidth: 1, borderColor: Colors.border,
  },
  searchInput: { flex: 1, color: Colors.text, fontSize: 14 },
  filterRow: { flexDirection: 'row', gap: 8 },
  filterBtn: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    backgroundColor: Colors.surfaceAlt, borderWidth: 1, borderColor: Colors.border,
  },
  filterBtnActive: { backgroundColor: Colors.primary + '20', borderColor: Colors.primary },
  filterText: { color: Colors.textSub, fontSize: 13, fontWeight: '600' },
  filterTextActive: { color: Colors.primary },
  usersList: { paddingHorizontal: 16, paddingBottom: 32 },
  sectionTitle: { color: Colors.textSub, fontSize: 13, fontWeight: '700', marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 },
  empty: { alignItems: 'center', paddingVertical: 40, gap: 12 },
  emptyText: { color: Colors.textMuted, fontSize: 15 },
});
