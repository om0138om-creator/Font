import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session } from '@supabase/supabase-js';
import * as WebBrowser from 'expo-web-browser';
import * as Linking from 'expo-linking';
import { supabase, getProfile, Profile } from '../lib/supabase';
import { registerForPushNotifications } from '../lib/pushNotifications';

WebBrowser.maybeCompleteAuthSession();

// ─── Context ──────────────────────────────────────────────────────────────────

type AuthContextType = {
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  isAdmin: boolean;
  isBanned: boolean;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

// ─── Provider ─────────────────────────────────────────────────────────────────

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const ADMIN_EMAIL = process.env.EXPO_PUBLIC_ADMIN_EMAIL ?? 'om011013om@gmail.com';

  const isAdmin = profile?.email === ADMIN_EMAIL || profile?.is_admin === true;
  const isBanned = profile?.is_banned === true;

  // ─── Load session on mount ───────────────────────────────────────────────

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) loadProfile(session.user.id);
      else setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);
      if (session) await loadProfile(session.user.id);
      else { setProfile(null); setLoading(false); }
    });

    return () => subscription.unsubscribe();
  }, []);

  const loadProfile = async (userId: string) => {
    setLoading(true);
    const p = await getProfile(userId);
    setProfile(p);
    if (p) {
      // Register push notifications silently
      registerForPushNotifications(userId).catch(() => {});
      // Update last_seen
      await supabase.from('profiles').update({ last_seen: new Date().toISOString() }).eq('id', userId);
    }
    setLoading(false);
  };

  const refreshProfile = async () => {
    if (session) await loadProfile(session.user.id);
  };

  // ─── Google OAuth ────────────────────────────────────────────────────────

  const signInWithGoogle = async () => {
    try {
      const redirectTo = Linking.createURL('/auth/callback');

      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo,
          skipBrowserRedirect: true,
          queryParams: { access_type: 'offline', prompt: 'consent' },
        },
      });

      if (error) throw error;
      if (!data.url) return;

      const result = await WebBrowser.openAuthSessionAsync(data.url, redirectTo);

      if (result.type === 'success') {
        const url = result.url;
        let accessToken: string | null = null;
        let refreshToken: string | null = null;

        // Extract from fragment
        if (url.includes('#')) {
          const frag = new URLSearchParams(url.split('#')[1]);
          accessToken = frag.get('access_token');
          refreshToken = frag.get('refresh_token');
        }
        // Fallback: query string
        if (!accessToken && url.includes('?')) {
          const q = new URLSearchParams(url.split('?')[1].split('#')[0]);
          accessToken = q.get('access_token');
          refreshToken = q.get('refresh_token');
        }

        if (accessToken && refreshToken) {
          await supabase.auth.setSession({ access_token: accessToken, refresh_token: refreshToken });
        }
      }
    } catch (err: any) {
      console.error('Google sign in error:', err.message);
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
  };

  return (
    <AuthContext.Provider value={{ session, profile, loading, isAdmin, isBanned, signInWithGoogle, signOut, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}
