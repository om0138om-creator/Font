import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';
import { Profile } from '../../lib/supabase';

type Props = {
  user: Profile;
  onBan: (id: string, ban: boolean) => void;
  onDelete: (id: string) => void;
};

export function UserCard({ user, onBan, onDelete }: Props) {
  const [expanded, setExpanded] = useState(false);

  const joinDate = new Date(user.created_at).toLocaleDateString('ar', {
    day: 'numeric', month: 'short', year: 'numeric',
  });

  const lastSeen = new Date(user.last_seen).toLocaleDateString('ar', {
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
  });

  const confirmDelete = () => {
    Alert.alert('حذف المستخدم', `هل تريد حذف ${user.full_name ?? user.email}؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => onDelete(user.id) },
    ]);
  };

  const confirmBan = () => {
    const action = user.is_banned ? 'رفع الحظر عن' : 'حظر';
    Alert.alert(`${action} المستخدم`, `هل تريد ${action} ${user.full_name ?? user.email}؟`, [
      { text: 'إلغاء', style: 'cancel' },
      { text: action, onPress: () => onBan(user.id, !user.is_banned) },
    ]);
  };

  return (
    <TouchableOpacity style={[styles.card, user.is_banned && styles.cardBanned]} onPress={() => setExpanded(!expanded)} activeOpacity={0.8}>
      <View style={styles.row}>
        {/* Avatar */}
        {user.avatar_url ? (
          <Image source={{ uri: user.avatar_url }} style={styles.avatar} />
        ) : (
          <View style={[styles.avatar, styles.avatarFallback]}>
            <Text style={styles.avatarLetter}>{(user.full_name ?? user.email ?? '?')[0].toUpperCase()}</Text>
          </View>
        )}

        {/* Info */}
        <View style={styles.info}>
          <View style={styles.nameRow}>
            <Text style={styles.name} numberOfLines={1}>{user.full_name ?? 'بدون اسم'}</Text>
            {user.is_admin && (
              <View style={styles.adminBadge}><Text style={styles.adminText}>مشرف</Text></View>
            )}
            {user.is_banned && (
              <View style={styles.bannedBadge}><Text style={styles.bannedText}>محظور</Text></View>
            )}
          </View>
          <Text style={styles.email} numberOfLines={1}>{user.email}</Text>
          <Text style={styles.date}>انضم: {joinDate}</Text>
        </View>

        <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textMuted} />
      </View>

      {/* Expanded details */}
      {expanded && (
        <View style={styles.details}>
          <View style={styles.detailRow}>
            <Ionicons name="time-outline" size={14} color={Colors.textMuted} />
            <Text style={styles.detailText}>آخر ظهور: {lastSeen}</Text>
          </View>
          {user.push_token && (
            <View style={styles.detailRow}>
              <Ionicons name="notifications-outline" size={14} color={Colors.textMuted} />
              <Text style={styles.detailText}>إشعارات: مُفعَّلة</Text>
            </View>
          )}
          {user.device_info && (
            <View style={styles.detailRow}>
              <Ionicons name="phone-portrait-outline" size={14} color={Colors.textMuted} />
              <Text style={styles.detailText}>{JSON.stringify(user.device_info).slice(0, 60)}...</Text>
            </View>
          )}

          {/* Actions */}
          {!user.is_admin && (
            <View style={styles.actions}>
              <TouchableOpacity style={[styles.actionBtn, user.is_banned ? styles.unbanBtn : styles.banBtn]} onPress={confirmBan}>
                <Ionicons name={user.is_banned ? 'checkmark-circle' : 'ban'} size={16} color={Colors.text} />
                <Text style={styles.actionText}>{user.is_banned ? 'رفع الحظر' : 'حظر'}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.actionBtn, styles.deleteBtn]} onPress={confirmDelete}>
                <Ionicons name="trash" size={16} color={Colors.text} />
                <Text style={styles.actionText}>حذف</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cardBanned: { borderColor: Colors.error + '55', backgroundColor: Colors.error + '08' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.surfaceAlt },
  avatarFallback: { justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.primary + '30' },
  avatarLetter: { color: Colors.primary, fontSize: 18, fontWeight: '700' },
  info: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' },
  name: { color: Colors.text, fontSize: 15, fontWeight: '700', flexShrink: 1 },
  email: { color: Colors.textSub, fontSize: 12, marginTop: 2 },
  date: { color: Colors.textMuted, fontSize: 11, marginTop: 2 },
  adminBadge: { backgroundColor: Colors.primary + '30', borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  adminText: { color: Colors.primary, fontSize: 10, fontWeight: '700' },
  bannedBadge: { backgroundColor: Colors.error + '30', borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 },
  bannedText: { color: Colors.error, fontSize: 10, fontWeight: '700' },
  details: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: Colors.border, gap: 6 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  detailText: { color: Colors.textMuted, fontSize: 12, flex: 1 },
  actions: { flexDirection: 'row', gap: 8, marginTop: 8 },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 8, borderRadius: 10 },
  banBtn: { backgroundColor: Colors.warning + 'BB' },
  unbanBtn: { backgroundColor: Colors.success + 'BB' },
  deleteBtn: { backgroundColor: Colors.error + 'BB' },
  actionText: { color: Colors.text, fontSize: 13, fontWeight: '700' },
});
