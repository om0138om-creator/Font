import React, { useState } from 'react';
import { View, Image, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';
import { CANVAS_SIZE } from '../../lib/fontEngine';

type Props = {
  imageUri: string | null;
  onClose: () => void;
  canvasSize: number;
};

export function ImageOverlay({ imageUri, onClose, canvasSize }: Props) {
  const [opacity, setOpacity] = useState(0.35);

  if (!imageUri) return null;

  return (
    <View style={[StyleSheet.absoluteFill, { width: canvasSize, height: canvasSize }]} pointerEvents="none">
      <Image
        source={{ uri: imageUri }}
        style={[StyleSheet.absoluteFill, { opacity }]}
        resizeMode="contain"
      />
      {/* Opacity controls — outside pointerEvents=none area */}
    </View>
  );
}
