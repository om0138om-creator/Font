import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';

export type Tool = 'pen' | 'select' | 'eraser' | 'move' | 'zoom';

type Props = {
  activeTool: Tool;
  onToolChange: (t: Tool) => void;
  onUndo: () => void;
  onRedo: () => void;
  onClear: () => void;
  onClose: () => void;
  canUndo: boolean;
  canRedo: boolean;
};

const TOOLS: { id: Tool; icon: string; label: string }[] = [
  { id: 'pen',    icon: 'pencil',           label: 'قلم'    },
  { id: 'select', icon: 'hand-left',        label: 'تحديد'  },
  { id: 'move',   icon: 'move',             label: 'تحريك'  },
  { id: 'eraser', icon: 'backspace',        label: 'ممحاة'  },
];

export function ToolBar({ activeTool, onToolChange, onUndo, onRedo, onClear, onClose, canUndo, canRedo }: Props) {
  return (
    <View style={styles.container}>
      {/* Tool Buttons */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.toolsRow}>
        {TOOLS.map(t => (
          <TouchableOpacity
            key={t.id}
            style={[styles.toolBtn, activeTool === t.id && styles.toolActive]}
            onPress={() => onToolChange(t.id)}
          >
            <Ionicons name={t.icon as any} size={20} color={activeTool === t.id ? Colors.primary : Colors.textSub} />
            <Text style={[styles.toolLabel, activeTool === t.id && { color: Colors.primary }]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Action Buttons */}
      <View style={styles.actions}>
        <TouchableOpacity style={[styles.actionBtn, !canUndo && styles.disabled]} onPress={onUndo} disabled={!canUndo}>
          <Ionicons name="arrow-undo" size={20} color={canUndo ? Colors.text : Colors.textMuted} />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionBtn, !canRedo && styles.disabled]} onPress={onRedo} disabled={!canRedo}>
          <Ionicons name="arrow-redo" size={20} color={canRedo ? Colors.text : Colors.textMuted} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={onClear}>
          <Ionicons name="trash-outline" size={20} color={Colors.error} />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionBtn, styles.doneBtn]} onPress={onClose}>
          <Text style={styles.doneText}>حفظ</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingHorizontal: 12,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toolsRow: { flexDirection: 'row', gap: 6, paddingRight: 8 },
  toolBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: Colors.surfaceAlt,
    minWidth: 56,
    gap: 2,
  },
  toolActive: { backgroundColor: Colors.primary + '25', borderWidth: 1, borderColor: Colors.primary },
  toolLabel: { fontSize: 10, color: Colors.textSub, fontWeight: '600' },
  actions: { flexDirection: 'row', gap: 6, marginLeft: 'auto' },
  actionBtn: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: Colors.surfaceAlt,
    justifyContent: 'center',
    alignItems: 'center',
  },
  doneBtn: { backgroundColor: Colors.primary, paddingHorizontal: 12, width: 'auto' },
  doneText: { color: Colors.text, fontWeight: '700', fontSize: 13 },
  disabled: { opacity: 0.4 },
});
