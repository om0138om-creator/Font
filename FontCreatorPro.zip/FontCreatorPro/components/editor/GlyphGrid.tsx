import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, FlatList } from 'react-native';
import { Colors } from '../../constants/colors';
import { GLYPH_CATEGORIES } from '../../constants/glyphs';
import { FontProject } from '../../lib/fontEngine';

type Props = {
  font: FontProject;
  onSelectChar: (char: string) => void;
};

export function GlyphGrid({ font, onSelectChar }: Props) {
  const [activeCat, setActiveCat] = useState(0);

  const chars = GLYPH_CATEGORIES[activeCat].chars;

  return (
    <View style={styles.container}>
      {/* Category tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabs}>
        {GLYPH_CATEGORIES.map((cat, i) => (
          <TouchableOpacity
            key={cat.name}
            style={[styles.tab, i === activeCat && styles.tabActive]}
            onPress={() => setActiveCat(i)}
          >
            <Text style={[styles.tabText, i === activeCat && styles.tabTextActive]}>
              {cat.nameAr}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Glyph cells */}
      <FlatList
        data={chars}
        keyExtractor={c => c}
        numColumns={7}
        contentContainerStyle={styles.grid}
        renderItem={({ item: char }) => {
          const hasDraw = Boolean(font.glyphs[char]?.path?.length);
          return (
            <TouchableOpacity
              style={[styles.cell, hasDraw && styles.cellDone]}
              onPress={() => onSelectChar(char)}
            >
              <Text style={[styles.cellChar, hasDraw && styles.cellCharDone]}>{char}</Text>
              {hasDraw && <View style={styles.dot} />}
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  tabs: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tab: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: Colors.surfaceAlt,
  },
  tabActive: { backgroundColor: Colors.primary },
  tabText: { color: Colors.textSub, fontSize: 13, fontWeight: '600' },
  tabTextActive: { color: Colors.text },
  grid: { padding: 8, gap: 6 },
  cell: {
    flex: 1,
    aspectRatio: 1,
    margin: 3,
    borderRadius: 10,
    backgroundColor: Colors.surfaceAlt,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    position: 'relative',
  },
  cellDone: { borderColor: Colors.primary + '88', backgroundColor: Colors.primary + '15' },
  cellChar: { fontSize: 18, color: Colors.textSub },
  cellCharDone: { color: Colors.text },
  dot: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: Colors.primary,
  },
});
