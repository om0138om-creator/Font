import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet } from 'react-native';
import { Colors } from '../../constants/colors';
import { FontProject } from '../../lib/fontEngine';

type Props = { font: FontProject };

const PREVIEW_TEXTS = [
  'الخط العربي',
  'Font Creator Pro',
  'أبجد هوز',
  'Hello World مرحبا',
  '٠١٢٣٤٥٦٧٨٩',
  'ABCDEFGHIJKLM',
];

export function FontPreview({ font }: Props) {
  const [customText, setCustomText] = useState('');
  const [fontSize, setFontSize] = useState(32);

  const drawnCount = Object.keys(font.glyphs).length;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.stat}>
          <Text style={styles.statNum}>{drawnCount}</Text>
          <Text style={styles.statLabel}>رمز مرسوم</Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statNum}>{font.metadata.unitsPerEm}</Text>
          <Text style={styles.statLabel}>UPM</Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statNum}>{font.metadata.ascender}</Text>
          <Text style={styles.statLabel}>صاعد</Text>
        </View>
      </View>

      {/* Font size slider */}
      <View style={styles.sizeRow}>
        <Text style={styles.sizeLabel}>الحجم: {fontSize}px</Text>
        <View style={styles.sizeButtons}>
          {[16, 24, 32, 48, 64].map(s => (
            <View key={s}
              style={[styles.sizeBtn, fontSize === s && styles.sizeBtnActive]}
            >
              <Text
                style={[styles.sizeBtnText, fontSize === s && { color: Colors.primary }]}
                onPress={() => setFontSize(s)}
              >{s}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Custom input */}
      <TextInput
        style={styles.input}
        placeholder="اكتب نصاً للمعاينة..."
        placeholderTextColor={Colors.textMuted}
        value={customText}
        onChangeText={setCustomText}
        textAlign="right"
      />

      {/* Drawn glyphs preview */}
      <View style={styles.glyphShowcase}>
        <Text style={styles.sectionTitle}>الحروف المرسومة</Text>
        <View style={styles.glyphRow}>
          {Object.keys(font.glyphs).map(char => (
            <View key={char} style={styles.glyphCell}>
              <Text style={[styles.glyphChar, { fontSize }]}>{char}</Text>
              <Text style={styles.glyphCode}>U+{char.codePointAt(0)?.toString(16).toUpperCase()}</Text>
            </View>
          ))}
        </View>
        {drawnCount === 0 && (
          <View style={styles.empty}>
            <Text style={styles.emptyText}>لا توجد حروف مرسومة بعد</Text>
            <Text style={styles.emptySubText}>ابدأ برسم الحروف من تبويب "الحروف"</Text>
          </View>
        )}
      </View>

      {/* Sample texts */}
      <View style={styles.samples}>
        <Text style={styles.sectionTitle}>نصوص تجريبية</Text>
        {PREVIEW_TEXTS.map(txt => (
          <View key={txt} style={styles.sampleCard}>
            <Text style={[styles.sampleText, { fontSize }]}>{txt}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  statsRow: { flexDirection: 'row', padding: 16, gap: 12 },
  stat: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  statNum: { color: Colors.primary, fontSize: 22, fontWeight: '800' },
  statLabel: { color: Colors.textSub, fontSize: 11, marginTop: 2 },
  sizeRow: { paddingHorizontal: 16, marginBottom: 12 },
  sizeLabel: { color: Colors.textSub, fontSize: 13, marginBottom: 8 },
  sizeButtons: { flexDirection: 'row', gap: 8 },
  sizeBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: Colors.surfaceAlt,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  sizeBtnActive: { borderColor: Colors.primary },
  sizeBtnText: { color: Colors.textSub, fontSize: 13, fontWeight: '600' },
  input: {
    marginHorizontal: 16,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 12,
    color: Colors.text,
    fontSize: 16,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: 16,
  },
  glyphShowcase: { paddingHorizontal: 16, marginBottom: 24 },
  sectionTitle: { color: Colors.textSub, fontSize: 13, fontWeight: '700', marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 },
  glyphRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  glyphCell: {
    backgroundColor: Colors.surface,
    borderRadius: 10,
    padding: 8,
    alignItems: 'center',
    minWidth: 56,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  glyphChar: { color: Colors.text, fontWeight: '400' },
  glyphCode: { color: Colors.textMuted, fontSize: 9, marginTop: 2 },
  empty: { padding: 32, alignItems: 'center' },
  emptyText: { color: Colors.textSub, fontSize: 16 },
  emptySubText: { color: Colors.textMuted, fontSize: 13, marginTop: 4 },
  samples: { paddingHorizontal: 16, paddingBottom: 32 },
  sampleCard: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  sampleText: { color: Colors.text },
});
