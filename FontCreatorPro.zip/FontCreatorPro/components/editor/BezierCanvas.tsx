import React, { useCallback, useRef, useState } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import {
  Canvas,
  Path,
  Circle,
  Line,
  Paint,
  useValue,
  runOnJS,
  Group,
  Text as SkText,
  useFont,
  Skia,
  matchFont,
} from '@shopify/react-native-skia';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import { Colors } from '../../constants/colors';
import { PathCmd, CANVAS_SIZE } from '../../lib/fontEngine';
import { Tool } from './ToolBar';

// ─── Types ────────────────────────────────────────────────────────────────────

type Point = { x: number; y: number };

type AnchorPoint = {
  id: string;
  x: number;
  y: number;
  cp1?: Point; // incoming control point
  cp2?: Point; // outgoing control point
};

type Contour = AnchorPoint[];

type CanvasState = {
  contours: Contour[];
  activeContourIdx: number;
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function dist(a: Point, b: Point) {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
}

function uid() {
  return Math.random().toString(36).slice(2);
}

function contoursToPathCmds(contours: Contour[]): PathCmd[] {
  const cmds: PathCmd[] = [];
  for (const contour of contours) {
    if (contour.length === 0) continue;
    cmds.push({ type: 'M', x: contour[0].x, y: contour[0].y });
    for (let i = 1; i < contour.length; i++) {
      const prev = contour[i - 1];
      const curr = contour[i];
      if (prev.cp2 || curr.cp1) {
        const cp1 = prev.cp2 ?? { x: (prev.x + curr.x) / 2, y: (prev.y + curr.y) / 2 };
        const cp2 = curr.cp1 ?? { x: (prev.x + curr.x) / 2, y: (prev.y + curr.y) / 2 };
        cmds.push({ type: 'C', x1: cp1.x, y1: cp1.y, x2: cp2.x, y2: cp2.y, x: curr.x, y: curr.y });
      } else {
        cmds.push({ type: 'L', x: curr.x, y: curr.y });
      }
    }
    if (contour.length > 2) cmds.push({ type: 'Z' });
  }
  return cmds;
}

function pathCmdsToContours(cmds: PathCmd[]): Contour[] {
  const contours: Contour[] = [];
  let current: Contour = [];
  for (const cmd of cmds) {
    if (cmd.type === 'M') {
      if (current.length) contours.push(current);
      current = [{ id: uid(), x: cmd.x, y: cmd.y }];
    } else if (cmd.type === 'L') {
      current.push({ id: uid(), x: cmd.x, y: cmd.y });
    } else if (cmd.type === 'C') {
      const last = current[current.length - 1];
      if (last) last.cp2 = { x: cmd.x1, y: cmd.y1 };
      current.push({ id: uid(), x: cmd.x, y: cmd.y, cp1: { x: cmd.x2, y: cmd.y2 } });
    } else if (cmd.type === 'Z') {
      if (current.length) contours.push(current);
      current = [];
    }
  }
  if (current.length) contours.push(current);
  return contours;
}

function buildSkiaPath(contours: Contour[]): string {
  let d = '';
  for (const contour of contours) {
    if (!contour.length) continue;
    d += `M ${contour[0].x} ${contour[0].y} `;
    for (let i = 1; i < contour.length; i++) {
      const prev = contour[i - 1];
      const curr = contour[i];
      if (prev.cp2 || curr.cp1) {
        const cp1 = prev.cp2 ?? { x: (prev.x + curr.x) / 2, y: (prev.y + curr.y) / 2 };
        const cp2 = curr.cp1 ?? { x: (prev.x + curr.x) / 2, y: (prev.y + curr.y) / 2 };
        d += `C ${cp1.x} ${cp1.y} ${cp2.x} ${cp2.y} ${curr.x} ${curr.y} `;
      } else {
        d += `L ${curr.x} ${curr.y} `;
      }
    }
    if (contour.length > 2) d += 'Z ';
  }
  return d;
}

// ─── Component ────────────────────────────────────────────────────────────────

type Props = {
  initialPath: PathCmd[];
  tool: Tool;
  onPathChange: (cmds: PathCmd[]) => void;
  char: string;
};

const SNAP = 20; // px snap distance for closing contours
const ANCHOR_R = 6;
const CP_R = 4;

export function BezierCanvas({ initialPath, tool, onPathChange, char }: Props) {
  const size = Math.min(Dimensions.get('window').width - 32, CANVAS_SIZE);
  const scale = size / CANVAS_SIZE;

  const [state, setState] = useState<CanvasState>(() => ({
    contours: pathCmdsToContours(initialPath),
    activeContourIdx: 0,
  }));

  // History for undo/redo — stored as serialized state
  const historyRef = useRef<CanvasState[]>([]);
  const historyIdxRef = useRef(-1);

  const [selectedAnchor, setSelectedAnchor] = useState<{ ci: number; ai: number } | null>(null);
  const [selectedCP, setSelectedCP] = useState<{ ci: number; ai: number; which: 'cp1' | 'cp2' } | null>(null);
  const draggingRef = useRef(false);

  const pushHistory = (newState: CanvasState) => {
    historyRef.current = historyRef.current.slice(0, historyIdxRef.current + 1);
    historyRef.current.push(JSON.parse(JSON.stringify(newState)));
    historyIdxRef.current = historyRef.current.length - 1;
  };

  const commitState = (newState: CanvasState) => {
    setState(newState);
    pushHistory(newState);
    onPathChange(contoursToPathCmds(newState.contours));
  };

  // ─── Tap (pen tool) ────────────────────────────────────────────────────────

  const tapGesture = Gesture.Tap().onEnd(e => {
    if (tool !== 'pen') return;
    const x = e.x / scale;
    const y = e.y / scale;
    runOnJS(handlePenTap)(x, y);
  });

  const handlePenTap = (x: number, y: number) => {
    const s = JSON.parse(JSON.stringify(state)) as CanvasState;
    let ci = s.activeContourIdx;

    if (!s.contours[ci]) {
      s.contours.push([]);
      ci = s.contours.length - 1;
      s.activeContourIdx = ci;
    }

    const contour = s.contours[ci];

    // Check if closing contour
    if (contour.length > 2) {
      const first = contour[0];
      if (dist({ x, y }, first) < SNAP) {
        // Close and start new contour
        s.contours.push([]);
        s.activeContourIdx = s.contours.length - 1;
        commitState(s);
        return;
      }
    }

    contour.push({ id: uid(), x, y });
    commitState(s);
  };

  // ─── Long press → add cubic bezier handle ─────────────────────────────────

  const longPressGesture = Gesture.LongPress().onStart(e => {
    if (tool !== 'pen') return;
    const x = e.x / scale;
    const y = e.y / scale;
    runOnJS(handleLongPress)(x, y);
  });

  const handleLongPress = (x: number, y: number) => {
    const s = JSON.parse(JSON.stringify(state)) as CanvasState;
    const ci = s.activeContourIdx;
    const contour = s.contours[ci];
    if (!contour?.length) return;

    // Find nearest anchor
    let nearest = -1;
    let nearestDist = Infinity;
    contour.forEach((a, i) => {
      const d = dist({ x, y }, a);
      if (d < nearestDist) { nearestDist = d; nearest = i; }
    });

    if (nearest >= 0 && nearestDist < SNAP * 2) {
      const a = contour[nearest];
      if (!a.cp2) a.cp2 = { x: a.x + 40, y: a.y - 40 };
      if (!a.cp1) a.cp1 = { x: a.x - 40, y: a.y + 40 };
      commitState(s);
    }
  };

  // ─── Pan (select / move / drag handles) ───────────────────────────────────

  const panStart = useRef<Point>({ x: 0, y: 0 });
  const panStartState = useRef<CanvasState>(state);

  const panGesture = Gesture.Pan()
    .onBegin(e => {
      const x = e.x / scale;
      const y = e.y / scale;
      panStart.current = { x, y };
      panStartState.current = JSON.parse(JSON.stringify(state));

      // Find what we're dragging
      runOnJS(beginDrag)(x, y);
    })
    .onUpdate(e => {
      const x = e.x / scale;
      const y = e.y / scale;
      runOnJS(updateDrag)(x, y);
    })
    .onEnd(() => {
      if (draggingRef.current) {
        runOnJS(endDrag)();
      }
    });

  const beginDrag = (x: number, y: number) => {
    if (tool !== 'select' && tool !== 'move') return;
    draggingRef.current = false;

    // Check control points first
    for (let ci = 0; ci < state.contours.length; ci++) {
      for (let ai = 0; ai < state.contours[ci].length; ai++) {
        const a = state.contours[ci][ai];
        if (a.cp1 && dist({ x, y }, a.cp1) < SNAP) {
          setSelectedCP({ ci, ai, which: 'cp1' });
          draggingRef.current = true;
          return;
        }
        if (a.cp2 && dist({ x, y }, a.cp2) < SNAP) {
          setSelectedCP({ ci, ai, which: 'cp2' });
          draggingRef.current = true;
          return;
        }
      }
    }
    // Check anchor points
    for (let ci = 0; ci < state.contours.length; ci++) {
      for (let ai = 0; ai < state.contours[ci].length; ai++) {
        const a = state.contours[ci][ai];
        if (dist({ x, y }, a) < SNAP) {
          setSelectedAnchor({ ci, ai });
          draggingRef.current = true;
          return;
        }
      }
    }
  };

  const updateDrag = (x: number, y: number) => {
    if (!draggingRef.current) return;
    const s = JSON.parse(JSON.stringify(panStartState.current)) as CanvasState;
    const dx = x - panStart.current.x;
    const dy = y - panStart.current.y;

    if (selectedCP) {
      const a = s.contours[selectedCP.ci]?.[selectedCP.ai];
      if (a) {
        if (selectedCP.which === 'cp1' && a.cp1) { a.cp1.x += dx; a.cp1.y += dy; }
        if (selectedCP.which === 'cp2' && a.cp2) { a.cp2.x += dx; a.cp2.y += dy; }
      }
    } else if (selectedAnchor) {
      const a = s.contours[selectedAnchor.ci]?.[selectedAnchor.ai];
      if (a) {
        a.x += dx;
        a.y += dy;
        if (a.cp1) { a.cp1.x += dx; a.cp1.y += dy; }
        if (a.cp2) { a.cp2.x += dx; a.cp2.y += dy; }
      }
    }

    setState(s);
    onPathChange(contoursToPathCmds(s.contours));
  };

  const endDrag = () => {
    if (draggingRef.current) {
      pushHistory(state);
      draggingRef.current = false;
    }
  };

  // ─── Erase tap ─────────────────────────────────────────────────────────────

  const eraseTap = Gesture.Tap().onEnd(e => {
    if (tool !== 'eraser') return;
    const x = e.x / scale;
    const y = e.y / scale;
    runOnJS(handleErase)(x, y);
  });

  const handleErase = (x: number, y: number) => {
    const s = JSON.parse(JSON.stringify(state)) as CanvasState;
    for (let ci = 0; ci < s.contours.length; ci++) {
      for (let ai = 0; ai < s.contours[ci].length; ai++) {
        if (dist({ x, y }, s.contours[ci][ai]) < SNAP * 1.5) {
          s.contours[ci].splice(ai, 1);
          if (s.contours[ci].length === 0) s.contours.splice(ci, 1);
          commitState(s);
          return;
        }
      }
    }
  };

  const composed = Gesture.Race(eraseTap, longPressGesture, panGesture, tapGesture);

  // ─── Render ────────────────────────────────────────────────────────────────

  const pathStr = buildSkiaPath(state.contours);
  const skPath = pathStr ? Skia.Path.MakeFromSVGString(pathStr) ?? undefined : undefined;

  return (
    <GestureDetector gesture={composed}>
      <View style={[styles.container, { width: size, height: size }]}>
        <Canvas style={{ width: size, height: size }}>
          {/* Grid */}
          {[...Array(10)].map((_, i) => {
            const pos = (i / 10) * size;
            return (
              <Group key={i}>
                <Line p1={{ x: pos, y: 0 }} p2={{ x: pos, y: size }} color={Colors.grid} strokeWidth={0.5} />
                <Line p1={{ x: 0, y: pos }} p2={{ x: size, y: pos }} color={Colors.grid} strokeWidth={0.5} />
              </Group>
            );
          })}

          {/* Baseline */}
          <Line p1={{ x: 0, y: size * 0.75 }} p2={{ x: size, y: size * 0.75 }} color={Colors.primary + '40'} strokeWidth={1} />
          {/* Cap height */}
          <Line p1={{ x: 0, y: size * 0.2 }} p2={{ x: size, y: size * 0.2 }} color={Colors.accent + '30'} strokeWidth={0.5} />
          {/* Descender */}
          <Line p1={{ x: 0, y: size * 0.9 }} p2={{ x: size, y: size * 0.9 }} color={Colors.secondary + '30'} strokeWidth={0.5} />

          {/* Ghost char */}
          {/* Filled glyph path */}
          {skPath && (
            <Path
              path={skPath}
              color={Colors.primary + '33'}
              style="fill"
            />
          )}
          {skPath && (
            <Path
              path={skPath}
              color={Colors.primary}
              style="stroke"
              strokeWidth={1.5 / scale}
            />
          )}

          {/* Control points & anchors */}
          {(tool === 'select' || tool === 'pen') && state.contours.map((contour, ci) =>
            contour.map((anchor, ai) => (
              <Group key={anchor.id}>
                {/* CP lines */}
                {anchor.cp1 && (
                  <>
                    <Line p1={{ x: anchor.cp1.x * scale, y: anchor.cp1.y * scale }} p2={{ x: anchor.x * scale, y: anchor.y * scale }} color={Colors.accent + '88'} strokeWidth={1} />
                    <Circle cx={anchor.cp1.x * scale} cy={anchor.cp1.y * scale} r={CP_R} color={Colors.accent} />
                  </>
                )}
                {anchor.cp2 && (
                  <>
                    <Line p1={{ x: anchor.cp2.x * scale, y: anchor.cp2.y * scale }} p2={{ x: anchor.x * scale, y: anchor.y * scale }} color={Colors.accent + '88'} strokeWidth={1} />
                    <Circle cx={anchor.cp2.x * scale} cy={anchor.cp2.y * scale} r={CP_R} color={Colors.accent} />
                  </>
                )}
                {/* Anchor */}
                <Circle
                  cx={anchor.x * scale}
                  cy={anchor.y * scale}
                  r={ANCHOR_R}
                  color={selectedAnchor?.ci === ci && selectedAnchor?.ai === ai ? Colors.secondary : Colors.text}
                />
                <Circle
                  cx={anchor.x * scale}
                  cy={anchor.y * scale}
                  r={ANCHOR_R - 2}
                  color={ci === state.activeContourIdx ? Colors.primary : Colors.surface}
                />
              </Group>
            ))
          )}
        </Canvas>

        {/* Character label */}
        <View style={styles.charLabel} pointerEvents="none">
          <View style={styles.charBadge}>
            {/* label shown via RN text, not Skia */}
          </View>
        </View>
      </View>
    </GestureDetector>
  );
}

// Expose undo/redo/clear via ref
export type BezierCanvasRef = {
  undo: () => void;
  redo: () => void;
  clear: () => void;
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.canvas,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  charLabel: { position: 'absolute', bottom: 8, right: 8 },
  charBadge: {
    backgroundColor: Colors.surface + 'CC',
    borderRadius: 8,
    padding: 4,
  },
});
