import React, { useEffect, useRef } from 'react';
import { Animated, Text, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '../../constants/colors';

type ToastType = 'success' | 'error' | 'info';

type Props = {
  message: string;
  type?: ToastType;
  visible: boolean;
  onHide: () => void;
};

export function Toast({ message, type = 'info', visible, onHide }: Props) {
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 220, useNativeDriver: true }),
        Animated.delay(2400),
        Animated.timing(opacity, { toValue: 0, duration: 220, useNativeDriver: true }),
      ]).start(() => onHide());
    }
  }, [visible]);

  if (!visible) return null;

  const config = {
    success: { icon: 'checkmark-circle', color: Colors.success },
    error: { icon: 'alert-circle', color: Colors.error },
    info: { icon: 'information-circle', color: Colors.primary },
  }[type];

  return (
    <Animated.View style={[styles.toast, { opacity }]}>
      <Ionicons name={config.icon as any} size={20} color={config.color} />
      <Text style={styles.message}>{message}</Text>
    </Animated.View>
  );
}

export function useToast() {
  const [state, setState] = React.useState<{ message: string; type: ToastType; visible: boolean }>({
    message: '', type: 'info', visible: false,
  });

  const show = (message: string, type: ToastType = 'info') => {
    setState({ message, type, visible: true });
  };

  const hide = () => setState(s => ({ ...s, visible: false }));

  return { toast: state, show, hide };
}

const styles = StyleSheet.create({
  toast: {
    position: 'absolute',
    bottom: 90,
    left: 24,
    right: 24,
    backgroundColor: Colors.surface,
    borderRadius: 14,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.border,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
    zIndex: 9999,
  },
  message: { color: Colors.text, fontSize: 14, fontWeight: '600', flex: 1 },
});
