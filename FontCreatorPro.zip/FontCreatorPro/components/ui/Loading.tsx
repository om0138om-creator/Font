import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import { Colors } from '../../constants/colors';

export function Loading({ size = 40 }: { size?: number }) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.timing(anim, { toValue: 1, duration: 1000, useNativeDriver: true })
    ).start();
  }, []);

  const rotate = anim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  return (
    <View style={styles.wrap}>
      <Animated.View style={[styles.spinner, { width: size, height: size, borderRadius: size / 2, transform: [{ rotate }] }]} />
    </View>
  );
}

export function FullScreenLoading() {
  return (
    <View style={styles.fullScreen}>
      <Loading size={50} />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { justifyContent: 'center', alignItems: 'center' },
  spinner: {
    borderWidth: 3,
    borderColor: Colors.border,
    borderTopColor: Colors.primary,
  },
  fullScreen: {
    flex: 1,
    backgroundColor: Colors.bg,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
