export type GlyphCategory = {
  name: string;
  nameAr: string;
  chars: string[];
};

export const GLYPH_CATEGORIES: GlyphCategory[] = [
  {
    name: 'Arabic',
    nameAr: 'عربي',
    chars: [
      'ا','ب','ت','ث','ج','ح','خ','د','ذ','ر','ز','س','ش','ص','ض','ط','ظ','ع','غ','ف',
      'ق','ك','ل','م','ن','ه','و','ي','ء','آ','أ','إ','ئ','ؤ','ة','ى',
      'لا','لأ','لإ','لآ',
    ],
  },
  {
    name: 'Arabic Diacritics',
    nameAr: 'تشكيل',
    chars: ['َ','ِ','ُ','ً','ٍ','ٌ','ْ','ّ','ـ'],
  },
  {
    name: 'Latin Uppercase',
    nameAr: 'لاتيني كبير',
    chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),
  },
  {
    name: 'Latin Lowercase',
    nameAr: 'لاتيني صغير',
    chars: 'abcdefghijklmnopqrstuvwxyz'.split(''),
  },
  {
    name: 'Arabic Numerals',
    nameAr: 'أرقام عربية',
    chars: ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'],
  },
  {
    name: 'Western Numerals',
    nameAr: 'أرقام غربية',
    chars: '0123456789'.split(''),
  },
  {
    name: 'Punctuation',
    nameAr: 'علامات ترقيم',
    chars: [
      '.',',',':',';','!','?','،','؟','؛','"',"'",'(',')','[',']','{','}',
      '-','_','/','\\','@','#','$','%','&','*','+','=','<','>',
    ],
  },
  {
    name: 'Symbols',
    nameAr: 'رموز',
    chars: ['©','®','™','°','±','×','÷','√','∞','≈','≠','≤','≥','←','→','↑','↓','♠','♥','♦','♣','★','☆'],
  },
];

export const ALL_GLYPHS = GLYPH_CATEGORIES.flatMap(c => c.chars);

export const DEFAULT_ADVANCE_WIDTH = 600;
export const UNITS_PER_EM = 1000;
export const ASCENDER = 800;
export const DESCENDER = -200;
