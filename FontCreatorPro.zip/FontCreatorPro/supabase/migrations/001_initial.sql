-- ═══════════════════════════════════════════════════
--  Font Creator Pro — Supabase Database Schema
--  Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── Profiles ────────────────────────────────────────

CREATE TABLE IF NOT EXISTS public.profiles (
  id            UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email         TEXT,
  full_name     TEXT,
  avatar_url    TEXT,
  is_banned     BOOLEAN DEFAULT FALSE NOT NULL,
  is_admin      BOOLEAN DEFAULT FALSE NOT NULL,
  push_token    TEXT,
  device_info   JSONB,
  created_at    TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  last_seen     TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Users can only read/update their own profile
CREATE POLICY "profiles_self_select" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "profiles_self_update" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- Admin can read all profiles
CREATE POLICY "profiles_admin_all" ON public.profiles
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND (p.is_admin = true OR p.email = 'om011013om@gmail.com')
    )
  );

-- ─── Fonts ───────────────────────────────────────────

CREATE TABLE IF NOT EXISTS public.fonts (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  name        TEXT NOT NULL,
  glyphs      JSONB DEFAULT '{}' NOT NULL,
  metadata    JSONB DEFAULT '{}' NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at  TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

ALTER TABLE public.fonts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "fonts_owner" ON public.fonts
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "fonts_admin" ON public.fonts
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND (p.is_admin = true OR p.email = 'om011013om@gmail.com')
    )
  );

-- ─── Auto-create profile on signup ────────────────────

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _email TEXT;
  _is_admin BOOLEAN;
BEGIN
  _email := new.email;
  _is_admin := (_email = 'om011013om@gmail.com');

  INSERT INTO public.profiles (id, email, full_name, avatar_url, is_admin)
  VALUES (
    new.id,
    _email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'avatar_url',
    _is_admin
  )
  ON CONFLICT (id) DO UPDATE SET
    email      = EXCLUDED.email,
    full_name  = COALESCE(EXCLUDED.full_name, profiles.full_name),
    avatar_url = COALESCE(EXCLUDED.avatar_url, profiles.avatar_url),
    last_seen  = NOW();

  RETURN new;
END;
$$;

-- Drop trigger if exists, then recreate
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ─── Update updated_at on font change ────────────────

CREATE OR REPLACE FUNCTION public.update_fonts_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS fonts_updated_at ON public.fonts;
CREATE TRIGGER fonts_updated_at
  BEFORE UPDATE ON public.fonts
  FOR EACH ROW EXECUTE FUNCTION public.update_fonts_updated_at();

-- ─── Helper: is current user admin ────────────────────

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT (email = 'om011013om@gmail.com' OR is_admin = true)
  FROM public.profiles
  WHERE id = auth.uid();
$$;

-- ─── Realtime: enable for admin notifications ─────────

ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
ALTER PUBLICATION supabase_realtime ADD TABLE public.fonts;

-- ─── Indexes ─────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_fonts_user_id ON public.fonts(user_id);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_created ON public.profiles(created_at DESC);
