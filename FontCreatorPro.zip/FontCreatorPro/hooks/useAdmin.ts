import { useEffect, useState, useCallback } from 'react';
import { supabase, Profile, getAllProfiles, banUser, deleteUserAccount } from '../lib/supabase';
import * as Notifications from 'expo-notifications';

type AdminStats = {
  totalUsers: number;
  activeToday: number;
  bannedUsers: number;
  totalFonts: number;
};

export function useAdmin(isAdmin: boolean) {
  const [users, setUsers] = useState<Profile[]>([]);
  const [stats, setStats] = useState<AdminStats>({ totalUsers: 0, activeToday: 0, bannedUsers: 0, totalFonts: 0 });
  const [loading, setLoading] = useState(false);
  const [newUserAlert, setNewUserAlert] = useState<Profile | null>(null);

  // ─── Load all data ─────────────────────────────────────────────────────────

  const loadData = useCallback(async () => {
    if (!isAdmin) return;
    setLoading(true);

    const [profilesResult, fontsResult] = await Promise.all([
      getAllProfiles(),
      supabase.from('fonts').select('id', { count: 'exact', head: true }),
    ]);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const active = profilesResult.filter(p => new Date(p.last_seen) >= today).length;
    const banned = profilesResult.filter(p => p.is_banned).length;

    setUsers(profilesResult);
    setStats({
      totalUsers: profilesResult.length,
      activeToday: active,
      bannedUsers: banned,
      totalFonts: fontsResult.count ?? 0,
    });
    setLoading(false);
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin) return;
    loadData();
  }, [loadData]);

  // ─── Realtime: new user joined ─────────────────────────────────────────────

  useEffect(() => {
    if (!isAdmin) return;

    const channel = supabase
      .channel('admin_profiles')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'profiles' },
        async (payload) => {
          const newUser = payload.new as Profile;
          setUsers(prev => [newUser, ...prev]);
          setStats(prev => ({ ...prev, totalUsers: prev.totalUsers + 1 }));
          setNewUserAlert(newUser);

          // Local notification for admin
          await Notifications.scheduleNotificationAsync({
            content: {
              title: '🎉 مستخدم جديد!',
              body: `${newUser.full_name ?? newUser.email ?? 'مستخدم'} انضم للتطبيق`,
              data: { userId: newUser.id },
            },
            trigger: null,
          });

          // Auto-clear alert
          setTimeout(() => setNewUserAlert(null), 5000);
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'profiles' },
        (payload) => {
          const updated = payload.new as Profile;
          setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
        }
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [isAdmin]);

  // ─── Actions ───────────────────────────────────────────────────────────────

  const handleBan = async (userId: string, banned: boolean) => {
    await banUser(userId, banned);
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_banned: banned } : u));
    setStats(prev => ({
      ...prev,
      bannedUsers: banned ? prev.bannedUsers + 1 : prev.bannedUsers - 1,
    }));
  };

  const handleDelete = async (userId: string) => {
    await deleteUserAccount(userId);
    setUsers(prev => prev.filter(u => u.id !== userId));
    setStats(prev => ({ ...prev, totalUsers: prev.totalUsers - 1 }));
  };

  return { users, stats, loading, newUserAlert, loadData, handleBan, handleDelete };
}
