import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import { supabase, FontRecord } from '../lib/supabase';
import { FontProject, GlyphData, createEmptyProject, generateId } from '../lib/fontEngine';

// ─── State ────────────────────────────────────────────────────────────────────

type FontStore = {
  fonts: FontProject[];
  activeFont: FontProject | null;
  loading: boolean;
  error: string | null;

  loadFonts: (userId: string) => Promise<void>;
  createFont: (userId: string, name: string) => Promise<FontProject>;
  updateFont: (font: FontProject) => Promise<void>;
  deleteFont: (fontId: string) => Promise<void>;
  setActiveFont: (font: FontProject | null) => void;
  updateGlyph: (fontId: string, glyph: GlyphData) => Promise<void>;
  deleteGlyph: (fontId: string, char: string) => Promise<void>;
};

// ─── Store ────────────────────────────────────────────────────────────────────

export const useFontStore = create<FontStore>()(
  immer((set, get) => ({
    fonts: [],
    activeFont: null,
    loading: false,
    error: null,

    loadFonts: async (userId: string) => {
      set(s => { s.loading = true; s.error = null; });
      const { data, error } = await supabase
        .from('fonts')
        .select('*')
        .eq('user_id', userId)
        .order('updated_at', { ascending: false });

      if (error) {
        set(s => { s.error = error.message; s.loading = false; });
        return;
      }

      const projects: FontProject[] = (data as FontRecord[]).map(r => ({
        id: r.id,
        name: r.name,
        metadata: r.metadata as any,
        glyphs: r.glyphs as any,
      }));

      set(s => { s.fonts = projects; s.loading = false; });
    },

    createFont: async (userId: string, name: string) => {
      const project = createEmptyProject(name);

      const { data, error } = await supabase
        .from('fonts')
        .insert({
          id: project.id,
          user_id: userId,
          name: project.name,
          glyphs: project.glyphs,
          metadata: project.metadata,
        })
        .select()
        .single();

      if (error) throw new Error(error.message);

      set(s => { s.fonts.unshift(project); });
      return project;
    },

    updateFont: async (font: FontProject) => {
      set(s => {
        const idx = s.fonts.findIndex(f => f.id === font.id);
        if (idx >= 0) s.fonts[idx] = font;
        if (s.activeFont?.id === font.id) s.activeFont = font;
      });

      await supabase.from('fonts').update({
        name: font.name,
        glyphs: font.glyphs,
        metadata: font.metadata,
        updated_at: new Date().toISOString(),
      }).eq('id', font.id);
    },

    deleteFont: async (fontId: string) => {
      set(s => {
        s.fonts = s.fonts.filter(f => f.id !== fontId);
        if (s.activeFont?.id === fontId) s.activeFont = null;
      });
      await supabase.from('fonts').delete().eq('id', fontId);
    },

    setActiveFont: (font) => set(s => { s.activeFont = font; }),

    updateGlyph: async (fontId: string, glyph: GlyphData) => {
      const fonts = get().fonts;
      const font = fonts.find(f => f.id === fontId);
      if (!font) return;

      const updated: FontProject = {
        ...font,
        glyphs: { ...font.glyphs, [glyph.char]: glyph },
      };

      await get().updateFont(updated);
    },

    deleteGlyph: async (fontId: string, char: string) => {
      const fonts = get().fonts;
      const font = fonts.find(f => f.id === fontId);
      if (!font) return;

      const glyphs = { ...font.glyphs };
      delete glyphs[char];

      await get().updateFont({ ...font, glyphs });
    },
  }))
);
